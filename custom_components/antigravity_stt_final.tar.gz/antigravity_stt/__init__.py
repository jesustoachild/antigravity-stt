"""The Antigravity STT integration."""
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from .const import DOMAIN
from .stt import AntigravitySTTProvider

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up Antigravity STT from a config entry."""
    hass.data.setdefault(DOMAIN, {})
    # 实例化并存储提供者
    hass.data[DOMAIN][entry.entry_id] = AntigravitySTTProvider(hass, entry)
    
    # 转发平台设置
    await hass.config_entries.async_forward_entry_setups(entry, ["stt"])
    return True

async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    unload_ok = await hass.config_entries.async_forward_entry_unload(entry, "stt")
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id)
    return unload_ok
