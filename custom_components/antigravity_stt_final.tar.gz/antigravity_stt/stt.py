import base64
import logging
import aiohttp
import json

from homeassistant.components.stt import (
    AudioBitRates,
    AudioChannels,
    AudioCodecs,
    AudioFormats,
    AudioSampleRates,
    Provider,
    SpeechMetadata,
    SpeechResult,
    SpeechResultState,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .const import DOMAIN, CONF_API_KEY, CONF_URL, CONF_MODEL

_LOGGER = logging.getLogger(__name__)

async def async_get_engine(hass: HomeAssistant, config_entry: ConfigEntry, config=None) -> Provider:
    """Return the STT engine."""
    # 从 hass.data 中获取已经初始化的实例
    return hass.data[DOMAIN][config_entry.entry_id]

class AntigravitySTTProvider(Provider):
    """The Antigravity STT provider."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        """Initialize the provider."""
        self.hass = hass
        self.entry = entry
        self._name = "Antigravity STT"

    @property
    def name(self) -> str:
        """Return the name of the provider."""
        return self._name

    @property
    def supported_languages(self) -> list[str]:
        """Return a list of supported languages."""
        return ["zh", "en", "zh-CN"]

    @property
    def supported_formats(self) -> list[AudioFormats]:
        """Return a list of supported formats."""
        return [AudioFormats.WAV, AudioFormats.OGG]

    @property
    def supported_codecs(self) -> list[AudioCodecs]:
        """Return a list of supported codecs."""
        return [AudioCodecs.PCM, AudioCodecs.OPUS]

    @property
    def supported_sample_rates(self) -> list[AudioSampleRates]:
        """Return a list of supported sample rates."""
        return [AudioSampleRates.SAMPLERATE_16000, AudioSampleRates.SAMPLERATE_44100, AudioSampleRates.SAMPLERATE_48000]

    @property
    def supported_bit_rates(self) -> list[AudioBitRates]:
        """Return a list of supported bit rates."""
        return [AudioBitRates.BITRATE_16]

    @property
    def supported_channels(self) -> list[AudioChannels]:
        """Return a list of supported channels."""
        return [AudioChannels.CHANNEL_MONO]

    async def async_process_audio_stream(
        self, metadata: SpeechMetadata, stream: aiohttp.StreamReader
    ) -> SpeechResult:
        """Process an audio stream to text."""
        audio_data = b""
        try:
            async for chunk in stream:
                audio_data += chunk
        except Exception as err:
            _LOGGER.error("Error reading audio stream: %s", err)
            return SpeechResult(None, SpeechResultState.ERROR)

        if not audio_data:
            _LOGGER.warning("Empty audio data received")
            return SpeechResult(None, SpeechResultState.ERROR)

        # 编码音频
        base64_audio = base64.b64encode(audio_data).decode("utf-8")
        
        url = self.entry.data.get(CONF_URL)
        api_key = self.entry.data.get(CONF_API_KEY)
        model = self.entry.data.get(CONF_MODEL, "gemini-3-flash")

        # 构建请求体
        payload = {
            "model": model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "请将这段语音转录为文字。请直接输出转录后的内容，不要有任何解释。"},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:audio/wav;base64,{base64_audio}"
                            }
                        }
                    ]
                }
            ],
            "temperature": 0
        }

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        session = async_get_clientsession(self.hass)
        try:
            async with session.post(url, json=payload, headers=headers, timeout=30) as response:
                response.raise_for_status()
                result_json = await response.json()
                text = result_json["choices"][0]["message"]["content"].strip()
                
                # 清洗冗余
                text = text.replace("**", "").replace("\"", "").replace("\n", "")
                if "：" in text:
                    text = text.split("：")[-1]
                
                _LOGGER.debug("Antigravity STT result: %s", text)
                return SpeechResult(text, SpeechResultState.SUCCESS)
        except Exception as err:
            _LOGGER.error("Error calling Antigravity API: %s", err)
            return SpeechResult(None, SpeechResultState.ERROR)
