import base64
import logging
import aiohttp
import json
import io
import wave
from collections.abc import AsyncIterable

from homeassistant.components.stt import (
    AudioBitRates,
    AudioChannels,
    AudioCodecs,
    AudioFormats,
    AudioSampleRates,
    SpeechMetadata,
    SpeechResult,
    SpeechResultState,
    SpeechToTextEntity,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .const import DOMAIN, CONF_API_KEY, CONF_URL, CONF_MODEL

_LOGGER = logging.getLogger(__name__)

async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Antigravity STT provider."""
    async_add_entities([AntigravitySTTEntity(hass, config_entry)])

class AntigravitySTTEntity(SpeechToTextEntity):
    """The Antigravity STT entity."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        """Initialize the provider."""
        self.hass = hass
        self.entry = entry
        self._attr_name = "Antigravity STT"
        self._attr_unique_id = f"{entry.entry_id}_stt"

    @property
    def supported_languages(self) -> list[str]:
        """Return a list of supported languages."""
        return ["zh", "en", "zh-CN"]

    @property
    def supported_formats(self) -> list[AudioFormats]:
        """Return a list of supported formats."""
        return [AudioFormats.WAV]

    @property
    def supported_codecs(self) -> list[AudioCodecs]:
        """Return a list of supported codecs."""
        return [AudioCodecs.PCM]

    @property
    def supported_sample_rates(self) -> list[AudioSampleRates]:
        """Return a list of supported sample rates."""
        return [AudioSampleRates.SAMPLERATE_16000, AudioSampleRates.SAMPLERATE_44100, AudioSampleRates.SAMPLERATE_48000]

    @property
    def supported_bit_rates(self) -> list[AudioBitRates]:
        """Return a list of supported bit rates."""
        return [AudioBitRates.BITRATE_16]

    @property
    def supported_channels(self) -> list[AudioChannels]:
        """Return a list of supported channels."""
        return [AudioChannels.CHANNEL_MONO]

    def _add_wav_header(self, pcm_data: bytes, sample_rate: int) -> bytes:
        """Add WAV header to raw PCM data."""
        with io.BytesIO() as wav_io:
            with wave.open(wav_io, 'wb') as wav_file:
                wav_file.setnchannels(1)
                wav_file.setsampwidth(2) # 16-bit
                wav_file.setframerate(sample_rate)
                wav_file.writeframes(pcm_data)
            return wav_io.getvalue()

    async def async_process_audio_stream(
        self, metadata: SpeechMetadata, stream: AsyncIterable[bytes]
    ) -> SpeechResult:
        """Process an audio stream to text."""
        raw_audio = b""
        try:
            async for chunk in stream:
                raw_audio += chunk
        except Exception as err:
            _LOGGER.error("Error reading audio stream: %s", err)
            return SpeechResult(None, SpeechResultState.ERROR)

        if not raw_audio:
            return SpeechResult(None, SpeechResultState.ERROR)

        # 核心：将原始 PCM 转换为标准格式 WAV
        wav_audio = self._add_wav_header(raw_audio, int(metadata.sample_rate))
        base64_audio = base64.b64encode(wav_audio).decode("utf-8")
        
        url = self.entry.data.get(CONF_URL)
        api_key = self.entry.data.get(CONF_API_KEY)
        model = self.entry.data.get(CONF_MODEL, "gemini-3-flash")

        payload = {
            "model": model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": "你是我的智能家居管家。请准确转录这段语音。直接返回转录文本。"
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:audio/wav;base64,{base64_audio}"
                            }
                        }
                    ]
                }
            ],
            "temperature": 0
        }

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        session = async_get_clientsession(self.hass)
        try:
            async with session.post(url, json=payload, headers=headers, timeout=30) as response:
                if response.status_code != 200:
                    error_text = await response.text()
                    _LOGGER.error("Antigravity STT Error %s: %s", response.status_code, error_text)
                    return SpeechResult(None, SpeechResultState.ERROR)
                
                result_json = await response.json()
                text = result_json["choices"][0]["message"]["content"].strip()
                text = text.replace("**", "").replace("\"", "").replace("\n", "").strip()
                if "：" in text:
                    text = text.split("：")[-1].strip()
                
                return SpeechResult(text, SpeechResultState.SUCCESS)
        except Exception as err:
            _LOGGER.error("Exception during Antigravity STT: %s", err)
            return SpeechResult(None, SpeechResultState.ERROR)
