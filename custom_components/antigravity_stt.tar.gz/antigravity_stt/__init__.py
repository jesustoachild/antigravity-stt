"""The Antigravity STT integration."""
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from .const import DOMAIN

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up Antigravity STT from a config entry."""
    hass.data.setdefault(DOMAIN, {})
    # 转发 STT 平台的设置
    await hass.config_entries.async_forward_entry_setups(entry, ["stt"])
    return True

async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    unload_ok = await hass.config_entries.async_forward_entry_unload(entry, "stt")
    return unload_ok
