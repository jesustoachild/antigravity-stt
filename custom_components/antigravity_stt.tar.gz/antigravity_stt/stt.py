import base64
import logging
import requests
import voluptuous as vol

from homeassistant.components.stt import (
    AudioAttributes,
    AudioFormats,
    AudioBitRates,
    AudioSampleRates,
    Provider,
    SpeechMetadata,
    SpeechResult,
    SpeechResultState,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN, CONF_API_KEY, CONF_URL, CONF_MODEL

_LOGGER = logging.getLogger(__name__)

async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Antigravity STT provider."""
    async_add_entities([AntigravitySTTProvider(hass, config_entry)])

class AntigravitySTTProvider(Provider):
    """The Antigravity STT provider."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        """Initialize the provider."""
        self.hass = hass
        self.entry = entry
        self._name = "Antigravity STT"

    @property
    def supported_languages(self) -> list[str]:
        """Return a list of supported languages."""
        return ["zh", "en"]

    @property
    def supported_formats(self) -> list[AudioFormats]:
        """Return a list of supported formats."""
        return [AudioFormats.WAV, AudioFormats.OGG]

    @property
    def supported_sample_rates(self) -> list[AudioSampleRates]:
        """Return a list of supported sample rates."""
        return [AudioSampleRates.SAMPLERATE_16000, AudioSampleRates.SAMPLERATE_44100, AudioSampleRates.SAMPLERATE_48000]

    @property
    def supported_bit_rates(self) -> list[AudioBitRates]:
        """Return a list of supported bit rates."""
        return [AudioBitRates.BITRATE_16]

    @property
    def supported_channels(self) -> list[int]:
        """Return a list of supported channels."""
        return [1]

    async def async_process_audio_stream(
        self, metadata: SpeechMetadata, stream: requests.Response
    ) -> SpeechResult:
        """Process an audio stream to text."""
        audio_data = b""
        async for chunk in stream:
            audio_data += chunk

        # 编码音频
        base64_audio = base64.b64encode(audio_data).decode("utf-8")
        
        url = self.entry.data.get(CONF_URL)
        api_key = self.entry.data.get(CONF_API_KEY)
        model = self.entry.data.get(CONF_MODEL, "gemini-3-flash")

        # 构建 OpenAI 格式的多模态请求（使用我们验证成功的格式）
        payload = {
            "model": model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "请将这段语音转录为文字。"},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:audio/wav;base64,{base64_audio}"
                            }
                        }
                    ]
                }
            ],
            "temperature": 0
        }

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        try:
            # 使用同步 requests 在 thread 中运行，或改用 aiohttp
            response = await self.hass.async_add_executor_job(
                lambda: requests.post(url, json=payload, headers=headers, timeout=30)
            )
            response.raise_for_status()
            result_json = response.json()
            text = result_json["choices"][0]["message"]["content"].strip()
            
            # 简单清洗：去除 Gemini 可能带有的 Markdown 标记
            text = text.replace("**", "").replace("\"", "")
            
            return SpeechResult(text, SpeechResultState.SUCCESS)
        except Exception as err:
            _LOGGER.error("Error transcribing audio with Antigravity: %s", err)
            return SpeechResult(None, SpeechResultState.ERROR)
