"""Constants for the Antigravity STT integration."""
DOMAIN = "antigravity_stt"
CONF_API_KEY = "api_key"
CONF_URL = "url"
CONF_MODEL = "model"

DEFAULT_MODEL = "gemini-3-flash"
DEFAULT_URL = "http://192.168.31.18:28045/v1/chat/completions"
