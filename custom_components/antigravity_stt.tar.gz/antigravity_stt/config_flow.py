"""Config flow for Antigravity STT integration."""
import voluptuous as vol
from homeassistant import config_entries
from homeassistant.core import callback
from .const import DOMAIN, CONF_API_KEY, CONF_URL, CONF_MODEL, DEFAULT_URL, DEFAULT_MODEL

class AntigravitySTTConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle a config flow for Antigravity STT."""

    VERSION = 1

    async def async_step_user(self, user_input=None):
        """Handle the initial step."""
        errors = {}
        if user_input is not None:
            return self.async_create_entry(title="Antigravity STT", data=user_input)

        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema(
                {
                    vol.Required(CONF_URL, default=DEFAULT_URL): str,
                    vol.Required(CONF_API_KEY): str,
                    vol.Optional(CONF_MODEL, default=DEFAULT_MODEL): str,
                }
            ),
            errors=errors,
        )
