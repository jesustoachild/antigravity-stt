import base64
import logging
import aiohttp
import json
from collections.abc import AsyncIterable

from homeassistant.components.stt import (
    AudioBitRates,
    AudioChannels,
    AudioCodecs,
    AudioFormats,
    AudioSampleRates,
    SpeechMetadata,
    SpeechResult,
    SpeechResultState,
    SpeechToTextEntity,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .const import DOMAIN, CONF_API_KEY, CONF_URL, CONF_MODEL

_LOGGER = logging.getLogger(__name__)

async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Antigravity STT provider."""
    async_add_entities([AntigravitySTTEntity(hass, config_entry)])

class AntigravitySTTEntity(SpeechToTextEntity):
    """The Antigravity STT entity."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        """Initialize the provider."""
        self.hass = hass
        self.entry = entry
        self._attr_name = "Antigravity STT"
        self._attr_unique_id = f"{entry.entry_id}_stt"

    @property
    def supported_languages(self) -> list[str]:
        """Return a list of supported languages."""
        return ["zh", "en", "zh-CN"]

    @property
    def supported_formats(self) -> list[AudioFormats]:
        """Return a list of supported formats."""
        return [AudioFormats.WAV, AudioFormats.OGG]

    @property
    def supported_codecs(self) -> list[AudioCodecs]:
        """Return a list of supported codecs."""
        return [AudioCodecs.PCM, AudioCodecs.OPUS]

    @property
    def supported_sample_rates(self) -> list[AudioSampleRates]:
        """Return a list of supported sample rates."""
        return [AudioSampleRates.SAMPLERATE_16000, AudioSampleRates.SAMPLERATE_44100, AudioSampleRates.SAMPLERATE_48000]

    @property
    def supported_bit_rates(self) -> list[AudioBitRates]:
        """Return a list of supported bit rates."""
        return [AudioBitRates.BITRATE_16]

    @property
    def supported_channels(self) -> list[AudioChannels]:
        """Return a list of supported channels."""
        return [AudioChannels.CHANNEL_MONO]

    async def async_process_audio_stream(
        self, metadata: SpeechMetadata, stream: AsyncIterable[bytes]
    ) -> SpeechResult:
        """Process an audio stream to text."""
        audio_data = b""
        try:
            async for chunk in stream:
                audio_data += chunk
        except Exception as err:
            _LOGGER.error("Error reading audio stream: %s", err)
            return SpeechResult(None, SpeechResultState.ERROR)

        if not audio_data:
            return SpeechResult(None, SpeechResultState.ERROR)

        base64_audio = base64.b64encode(audio_data).decode("utf-8")
        
        url = self.entry.data.get(CONF_URL)
        api_key = self.entry.data.get(CONF_API_KEY)
        model = self.entry.data.get(CONF_MODEL, "gemini-3-flash")

        # 根据元数据动态判断 MIME 类型
        mime_type = "audio/wav"
        if metadata.format == AudioFormats.OGG:
            mime_type = "audio/ogg"

        payload = {
            "model": model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": "你是我的智能家居管家。请准确转录这段语音内容。已知设备：学霸灯、大象灯、孔雀灯、女王灯、低音炮、加湿器、停车灯。请直接返回转录文本。"
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:{mime_type};base64,{base64_audio}"
                            }
                        }
                    ]
                }
            ],
            "temperature": 0
        }

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        session = async_get_clientsession(self.hass)
        try:
            async with session.post(url, json=payload, headers=headers, timeout=30) as response:
                if response.status_code != 200:
                    error_text = await response.text()
                    _LOGGER.error("Antigravity API HTTP %s: %s", response.status_code, error_text)
                    return SpeechResult(None, SpeechResultState.ERROR)
                
                result_json = await response.json()
                text = result_json["choices"][0]["message"]["content"].strip()
                
                # 进一步清洗
                text = text.replace("**", "").replace("\"", "").replace("\n", "").strip()
                if "：" in text:
                    text = text.split("：")[-1].strip()
                
                _LOGGER.info("Antigravity STT Success: %s", text)
                return SpeechResult(text, SpeechResultState.SUCCESS)
        except Exception as err:
            _LOGGER.error("Exception during Antigravity STT: %s", err)
            return SpeechResult(None, SpeechResultState.ERROR)
